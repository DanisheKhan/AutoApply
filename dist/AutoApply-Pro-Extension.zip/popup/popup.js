/**
 * AutoApply Pro - Extension Popup Script
 */

document.addEventListener('DOMContentLoaded', async () => {
  const platformEl = document.getElementById('detected-platform');
  const tagEl = document.getElementById('platform-tag');
  const autofillBtn = document.getElementById('btn-autofill');
  const snipBtn = document.getElementById('btn-snip-fill');
  const aiBtn = document.getElementById('btn-ai-fill');
  const statusMsg = document.getElementById('status-message');
  const optionsBtn = document.getElementById('btn-open-options');
  const testsBtn = document.getElementById('btn-open-tests');
  const widgetToggle = document.getElementById('widget-toggle');
  const widgetPill = document.getElementById('floating-toggle-pill');
  const widgetStatusDot = document.getElementById('widget-status-dot');
  const widgetStatusText = document.getElementById('widget-status-text');

  // Helper to sync toggle UI
  function updateToggleUI(isEnabled) {
    if (!widgetToggle) return;
    widgetToggle.checked = isEnabled;
    if (isEnabled) {
      if (widgetStatusDot) widgetStatusDot.classList.remove('inactive');
      if (widgetStatusText) widgetStatusText.textContent = "Active";
      if (widgetPill) {
        widgetPill.classList.remove('inactive');
        widgetPill.title = "Floating Button: Active (Click to deactivate)";
      }
    } else {
      if (widgetStatusDot) widgetStatusDot.classList.add('inactive');
      if (widgetStatusText) widgetStatusText.textContent = "Inactive";
      if (widgetPill) {
        widgetPill.classList.add('inactive');
        widgetPill.title = "Floating Button: Inactive (Click to activate)";
      }
    }
  }

  // Load initial floating widget preference
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(['floatingWidgetEnabled'], (data) => {
      const isEnabled = data.floatingWidgetEnabled !== false; // Default: true
      updateToggleUI(isEnabled);
    });
  }

  // Query Active Tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  // Floating Box Toggle Change Listener
  if (widgetToggle) {
    widgetToggle.addEventListener('change', () => {
      const isEnabled = widgetToggle.checked;
      updateToggleUI(isEnabled);

      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ floatingWidgetEnabled: isEnabled });
      }

      if (tab && tab.id) {
        chrome.tabs.sendMessage(tab.id, {
          action: "SET_WIDGET_VISIBILITY",
          enabled: isEnabled
        }, () => {
          if (chrome.runtime.lastError) {
            // Tab may not have content script loaded yet
          }
        });
      }

      if (statusMsg) {
        statusMsg.className = "status-message";
        statusMsg.textContent = isEnabled ? "Floating button activated on pages." : "Floating button deactivated.";
      }
    });
  }

  if (!tab || !tab.id) {
    platformEl.textContent = "No active tab";
    return;
  }

  // Ask content script for platform status
  chrome.tabs.sendMessage(tab.id, { action: "GET_PAGE_STATUS" }, (response) => {
    if (chrome.runtime.lastError || !response) {
      platformEl.textContent = "Ready on Standby";
      tagEl.textContent = "STANDBY";
      tagEl.className = "badge-tag standby";
      if (statusMsg) statusMsg.textContent = "Open any job application or press Alt+Shift+F";
      return;
    }

    if (response.isJobForm) {
      platformEl.textContent = response.platform || "Job Application";
      tagEl.textContent = "JOB FORM";
      tagEl.className = "badge-tag job-active";
      if (statusMsg) {
        statusMsg.className = "status-message success";
        statusMsg.textContent = response.fieldCount 
          ? `✓ Detected ${response.fieldCount} fields ready for autofill` 
          : `✓ Job form detected on this page`;
      }
    } else {
      platformEl.textContent = response.platform || "Standard Web Page";
      tagEl.textContent = "STANDBY";
      tagEl.className = "badge-tag standby";
      if (statusMsg) {
        statusMsg.className = "status-message";
        statusMsg.textContent = "Standing by. Autofill activates on job forms or via shortcut.";
      }
    }
  });

  // Autofill Click
  autofillBtn.addEventListener('click', () => {
    autofillBtn.disabled = true;
    statusMsg.className = "status-message thinking";
    statusMsg.textContent = "⚡ Dispatching form autofill...";

    chrome.tabs.sendMessage(tab.id, { action: "TRIGGER_AUTOFILL" }, (res) => {
      autofillBtn.disabled = false;
      if (chrome.runtime.lastError) {
        statusMsg.className = "status-message";
        statusMsg.textContent = "Please reload the job page once to activate.";
        return;
      }

      if (res && res.success && res.result) {
        statusMsg.className = "status-message success";
        statusMsg.textContent = `✓ Filled ${res.result.filledCount} fields on ${res.result.platform}!`;
      } else {
        statusMsg.className = "status-message";
        statusMsg.textContent = res?.error || "Autofill completed.";
      }
    });
  });

  // Snip & Fill Click
  if (snipBtn) {
    snipBtn.addEventListener('click', () => {
      chrome.tabs.sendMessage(tab.id, { action: "TRIGGER_SNIP_FILL" }, () => {
        if (chrome.runtime.lastError) {
          if (statusMsg) {
            statusMsg.className = "status-message";
            statusMsg.textContent = "Please reload the job page once to activate.";
          }
        } else {
          // Close the popup so user can immediately drag to select on the webpage
          window.close();
        }
      });
    });
  }

  // AI Question Solver Click
  aiBtn.addEventListener('click', () => {
    aiBtn.disabled = true;
    statusMsg.className = "status-message thinking";
    statusMsg.textContent = "✨ Calling Gemini AI for custom essays...";

    chrome.tabs.sendMessage(tab.id, { action: "TRIGGER_AI_FILL" }, (res) => {
      aiBtn.disabled = false;
      if (chrome.runtime.lastError) {
        statusMsg.className = "status-message";
        statusMsg.textContent = "Please reload the job page once to activate.";
        return;
      }

      if (res && res.success && res.result) {
        statusMsg.className = "status-message success";
        statusMsg.textContent = `✓ Generated ${res.result.aiCount} tailored answers!`;
      } else {
        statusMsg.className = "status-message";
        statusMsg.textContent = res?.error || "AI generation completed.";
      }
    });
  });

  // Upload Resume Click
  const resumeBtn = document.getElementById('btn-upload-resume');
  if (resumeBtn) {
    resumeBtn.addEventListener('click', () => {
      resumeBtn.disabled = true;
      statusMsg.className = "status-message thinking";
      statusMsg.textContent = "Attaching DanishKhan_Resume.pdf...";

      chrome.tabs.sendMessage(tab.id, { action: "TRIGGER_UPLOAD_RESUME" }, (res) => {
        resumeBtn.disabled = false;
        if (chrome.runtime.lastError) {
          statusMsg.className = "status-message";
          statusMsg.textContent = "Please reload the job page once to activate.";
          return;
        }

        if (res && res.success && res.result && res.result.uploaded) {
          statusMsg.className = "status-message success";
          statusMsg.textContent = `✓ Attached ${res.result.filename || 'DanishKhan_Resume.pdf'}!`;
        } else {
          statusMsg.className = "status-message";
          statusMsg.textContent = res?.error || "No resume dropzone detected on this page.";
        }
      });
    });
  }

  // Open Options / Bio Manager
  optionsBtn.addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });

  // Open Test Suite
  testsBtn.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('test-page/index.html') });
  });
});
